# Lincha Express — Website Starter

This is a lightweight landing page with:
- Hero + Services
- Instant quote calculator (demo)
- WhatsApp booking handoff
- Basic tracking mock

## How to use
1. Download the folder and open `index.html` in a browser.
2. Replace the WhatsApp number in `main.js` if needed.
3. Deploy to Netlify/Vercel by dragging the folder.

## Next steps
- Hook `quoteForm` to your backend to compute real distance.
- Replace tracking mock with your API.
- Add seller login and pricing page.
