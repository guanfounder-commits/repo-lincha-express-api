// Distance + pricing demo (same as starter)
function distanceFromPostal(a, b){
  const na = parseInt(String(a).slice(-2)) || 0;
  const nb = parseInt(String(b).slice(-2)) || 0;
  return Math.max(2, Math.abs(na - nb));
}
function calcPrice(service, km, urgency){
  let base = service==='parcel'?6: (service==='furniture'?60:35);
  let perKm = service==='parcel'?0.8:(service==='furniture'?2.5:1.2);
  let price = base + perKm * km;
  const surge = urgency==='instant'?1.5 : urgency==='rush'?1.25 : 1;
  return Math.round(price * surge);
}
function hookupQuote(){
  const qf = document.getElementById('quoteForm');
  if(!qf) return;
  qf.addEventListener('submit', (e)=>{
    e.preventDefault();
    const service = document.getElementById('service').value;
    const from = document.getElementById('from').value;
    const to = document.getElementById('to').value;
    const urgency = document.getElementById('urgency').value;
    const km = distanceFromPostal(from, to);
    const price = calcPrice(service, km, urgency);
    const text = `Estimated ${service} price for ~${km} km (${urgency}): SGD ${price}`;
    const el = document.getElementById('quoteResult');
    if(el) el.innerText = text + '\nNote: Final price confirmed on WhatsApp.';
    const waBtn = document.getElementById('whatsappBtn');
    const wa = `https://wa.me/6596277112?text=${encodeURIComponent('[QUOTE REQUEST]\nService: '+service+'\nFrom: '+from+'\nTo: '+to+'\nUrgency: '+urgency+'\nEstimated: SGD '+price)}`;
    if(waBtn) waBtn.href = wa;
  });
}
function hookupTracker(){
  const tf = document.getElementById('trackForm');
  if(!tf) return;
  tf.addEventListener('submit',(e)=>{
    e.preventDefault();
    const id = document.getElementById('trackingId').value.trim();
    document.getElementById('trackResult').innerText = id ? 'Status: Assigned → En‑route → ETA 45 mins (demo)' : '';
  });
}
function hookupTestimonials(){
  const rot = document.getElementById('rotator');
  if(!rot) return;
  const items = [...rot.querySelectorAll('.item')];
  let i = 0;
  setInterval(()=>{
    items[i].classList.remove('active');
    i = (i+1) % items.length;
    items[i].classList.add('active');
  }, 3500);
}
function hookupFAQ(){
  document.querySelectorAll('[data-q]').forEach(q=>{
    q.addEventListener('click',()=>{
      const a = q.nextElementSibling;
      a.style.display = a.style.display==='block' ? 'none' : 'block';
    });
  });
}
hookupQuote(); hookupTracker(); hookupTestimonials(); hookupFAQ();
